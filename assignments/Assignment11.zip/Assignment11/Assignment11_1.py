import os
import hashlib
import argparse
import logging


logging.basicConfig(filename='directory_checksum.log', level=logging.INFO, 
                    format='%(asctime)s:%(levelname)s:%(message)s')

def main():
    args = parse_arguments()
    directory = args.directory
    
    if validate_directory(directory):
        checksums = calculate_checksums(directory)
        log_checksums(checksums)
    else:
        logging.error(f"Invalid directory: {directory}")

def parse_arguments():
    parser = argparse.ArgumentParser(description="Calculate checksums of all files in a directory.")
    parser.add_argument("directory", help="Name of the directory")
    return parser.parse_args()

def validate_directory(directory):
    if not os.path.isdir(directory):
        return False
    return True

def calculate_checksums(directory):
    checksums = {}
    try:
        for root, _, files in os.walk(directory):
            for file in files:
                file_path = os.path.join(root, file)
                file_checksum = calculate_md5(file_path)
                checksums[file_path] = file_checksum
    except Exception as e:
        logging.error(f"Error while calculating checksums: {e}")
    return checksums

def calculate_md5(file_path):
    hash_md5 = hashlib.md5()
    try:
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()
    except Exception as e:
        logging.error(f"Error while reading file {file_path}: {e}")
        return None

def log_checksums(checksums):
    for file_path, checksum in checksums.items():
        if checksum:
            logging.info(f"File: {file_path}, Checksum: {checksum}")
        else:
            logging.warning(f"Checksum for file {file_path} could not be calculated.")

if __name__ == "__main__":
    main()
