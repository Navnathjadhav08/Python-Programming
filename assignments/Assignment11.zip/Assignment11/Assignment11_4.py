import os
import hashlib
import argparse
import logging
from collections import defaultdict
from time import time

# Setting up logging
logging.basicConfig(filename='Log.txt', level=logging.INFO, 
                    format='%(asctime)s:%(levelname)s:%(message)s')

# Define the main function to handle command line arguments and calculate execution time
def main():
    start_time = time()
    args = parse_arguments()
    directory = args.directory
    
    if validate_directory(directory):
        duplicates = find_duplicates(directory)
        delete_duplicates(duplicates)
        log_duplicates(duplicates)
    else:
        logging.error(f"Invalid directory: {directory}")

    end_time = time()
    execution_time = end_time - start_time
    print(f"Execution time: {execution_time:.2f} seconds")

# Function to parse command line arguments
def parse_arguments():
    parser = argparse.ArgumentParser(description="Find, log, and delete duplicate files in a directory.")
    parser.add_argument("directory", help="Name of the directory")
    return parser.parse_args()

# Function to validate the directory
def validate_directory(directory):
    if not os.path.isdir(directory):
        return False
    return True

# Function to find duplicate files in the directory
def find_duplicates(directory):
    file_hashes = defaultdict(list)
    try:
        for root, _, files in os.walk(directory):
            for file in files:
                file_path = os.path.join(root, file)
                file_hash = calculate_md5(file_path)
                if file_hash:
                    file_hashes[file_hash].append(file_path)
    except Exception as e:
        logging.error(f"Error while finding duplicates: {e}")

    duplicates = {hash_val: paths for hash_val, paths in file_hashes.items() if len(paths) > 1}
    return duplicates

# Function to calculate the MD5 checksum of a file
def calculate_md5(file_path):
    hash_md5 = hashlib.md5()
    try:
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()
    except Exception as e:
        logging.error(f"Error while reading file {file_path}: {e}")
        return None

# Function to delete duplicate files
def delete_duplicates(duplicates):
    for file_paths in duplicates.values():
        for file_path in file_paths[1:]:  # Keep the first file, delete the rest
            try:
                os.remove(file_path)
                logging.info(f"Deleted duplicate file: {file_path}")
            except Exception as e:
                logging.error(f"Error while deleting file {file_path}: {e}")

# Function to log the duplicates
def log_duplicates(duplicates):
    for hash_val, file_paths in duplicates.items():
        logging.info(f"Duplicate files for hash {hash_val}:")
        for file_path in file_paths:
            logging.info(f"\t{file_path}")

if __name__ == "__main__":
    main()
